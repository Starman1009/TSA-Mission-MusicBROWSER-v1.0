/**
 * The static class who handle easing in 2D
 */
export declare class Easing {
    constructor();
}
